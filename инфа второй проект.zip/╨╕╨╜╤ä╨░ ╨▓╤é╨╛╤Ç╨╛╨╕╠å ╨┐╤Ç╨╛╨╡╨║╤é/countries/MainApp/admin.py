from django.contrib import admin
from MainApp.models import Country


admin.site.register(Country)